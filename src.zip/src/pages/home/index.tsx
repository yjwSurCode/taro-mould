/* eslint-disable jsx-quotes */
import { Component, useRef, useState } from "react";
import Taro, { useRouter } from "@tarojs/taro";
import { useDispatch, useSelector } from "react-redux";
import { View, Button, Image, Text, Picker } from "@tarojs/components";
import { add, asyncAdd } from "../../store/actions";
import { StoreStatus, OrderStatus } from "../../store/types/index";
import {
  AtTabs,
  AtTabsPane,
  AtNavBar,
  AtModal,
  AtModalAction,
  AtModalContent,
  AtModalHeader,
  AtCurtain,
  AtGrid,
  AtList,
  AtListItem,
} from "taro-ui";
export default function Home(): ReturnType<Taro.FC> {
  const router = useRouter();

  const dispatch = useDispatch();
  const order: OrderStatus = useSelector((state: StoreStatus) => state.order);

  const [list, setList] = useState<any>([
    {
      title: "小学英语~重难点讲课",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F14.png",
      dic: "417人正在学习",
    },
    {
      title: "小学数学~重难点讲课",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      dic: "555人正在学习",
    },
    {
      title: "小学语文~重难点讲课",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      dic: "666人正在学习",
    },
    {
      title: "小学编程~重难点讲课",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F7.png",
      dic: "777人正在学习",
    },
  ]);

  const [infoList, setInfoList] = useState<any>([
    {
      title: "2020各省份物理中考分析重难点",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F14.png",
      dic: "417人正在学习",
    },
    {
      title: "2021各省份物理中考分析重难点",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      dic: "555人正在学习",
    },
    {
      title: "2022各省份物理中考分析重难点",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F14.png",
      dic: "666人正在学习",
    },
    {
      title: "2023各省份物理中考分析重难点",
      price: "29",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F7.png",
      dic: "777人正在学习",
    },
  ]);

  // TODO  {order.counter.num} 具体到某一个值
  console.log("router", router, order);

  return (
    <View className="index">
      <Image
        style={{ height: "250px", width: "100%" }}
        src="http://rbleiojei.hn-bkt.clouddn.com/design%2F12.png"
      ></Image>
      <AtGrid
        columnNum={4}
        data={[
          {
            image:
              "https://img12.360buyimg.com/jdphoto/s72x72_jfs/t6160/14/2008729947/2754/7d512a86/595c3aeeNa89ddf71.png",
            value: "语文",
          },
          {
            image:
              "https://img20.360buyimg.com/jdphoto/s72x72_jfs/t15151/308/1012305375/2300/536ee6ef/5a411466N040a074b.png",
            value: "数学",
          },
          {
            image:
              "https://img10.360buyimg.com/jdphoto/s72x72_jfs/t5872/209/5240187906/2872/8fa98cd/595c3b2aN4155b931.png",
            value: "英语",
          },
          {
            image:
              "https://img12.360buyimg.com/jdphoto/s72x72_jfs/t10660/330/203667368/1672/801735d7/59c85643N31e68303.png",
            value: "物理",
          },
          {
            image:
              "https://img14.360buyimg.com/jdphoto/s72x72_jfs/t17251/336/1311038817/3177/72595a07/5ac44618Na1db7b09.png",
            value: "化学",
          },
          {
            image:
              "https://img30.360buyimg.com/jdphoto/s72x72_jfs/t5770/97/5184449507/2423/294d5f95/595c3b4dNbc6bc95d.png",
            value: "历史",
          },
          {
            image:
              "https://img30.360buyimg.com/jdphoto/s72x72_jfs/t5770/97/5184449507/2423/294d5f95/595c3b4dNbc6bc95d.png",
            value: "编程",
          },
          {
            image:
              "https://img12.360buyimg.com/jdphoto/s72x72_jfs/t10660/330/203667368/1672/801735d7/59c85643N31e68303.png",
            value: "生物",
          },
        ]}
      />
      <Image
        style={{ height: "150px", width: "100%" }}
        src="http://rbleiojei.hn-bkt.clouddn.com/design%2F13.png"
      ></Image>
      <AtList>
        <AtListItem
          title="名师精品课"
          note=""
          extraText="更多课程"
          arrow="right"
          thumb="http://img12.360buyimg.com/jdphoto/s72x72_jfs/t10660/330/203667368/1672/801735d7/59c85643N31e68303.png"
        />
      </AtList>

      {list.map((item, index) => {
        return (
          <View
            style={{
              display: "flex",
              backgroundColor: "white",
              padding: "10px",
              marginBottom: "20px",
              borderRadius: "5px",
              position: "relative",
            }}
          >
            <Image
              style={{ height: "100px", width: "100px" }}
              src={item.img}
            ></Image>

            <View>
              <View className="course-title">{item.title}</View>
              <Image
                style={{ height: "25px", width: "150px" }}
                src={item.imgs}
              ></Image>
              <View className="course-price" style={{ fontWeight: "bold" }}>
                ￥{item.price}
              </View>
            </View>
            <View
              style="position: absolute;
    right: 10px;
    bottom: 10px;
    color: #dadada;"
            >
              {item.dic}
            </View>
          </View>
        );
      })}

      <Image
        style={{ height: "550px", width: "100%" }}
        src="http://rbleiojei.hn-bkt.clouddn.com/design%2F15.png"
      ></Image>

      <AtList>
        <AtListItem
          title="行业资讯"
          note=""
          extraText="更多质讯"
          arrow="right"
          // thumb="http://img12.360buyimg.com/jdphoto/s72x72_jfs/t10660/330/203667368/1672/801735d7/59c85643N31e68303.png"
        />
      </AtList>

      {infoList.map((item, index) => {
        return (
          <View
            style={{
              display: "flex",
              backgroundColor: "white",
              padding: "10px",
              marginBottom: "20px",
              borderRadius: "5px",
              position: "relative",
            }}
          >
            <View
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-around",
                paddingRight: "10px",
              }}
            >
              <View>{item.title}</View>
              <Image
                style={{ height: "25px", width: "100%" }}
                src="http://rbleiojei.hn-bkt.clouddn.com/design%2F16.png"
              ></Image>
            </View>

            <Image
              style={{ height: "80px", width: "100px" }}
              src={item.img}
            ></Image>
          </View>
        );
      })}

      {/* <Button onClick={() => dispatch(asyncAdd(1))}>++++++++++++++</Button> */}
    </View>
  );
}
