/* eslint-disable jsx-quotes */
import { Component, useRef, useState } from "react";
import Taro, { useRouter } from "@tarojs/taro";
import { useDispatch, useSelector } from "react-redux";
import { View, Button, Image, Text, Picker } from "@tarojs/components";
import { add, asyncAdd } from "../../store/actions";
import { StoreStatus, OrderStatus } from "../../store/types/index";
import {
  AtTabs,
  AtTabsPane,
  AtNavBar,
  AtModal,
  AtModalAction,
  AtModalContent,
  AtModalHeader,
  AtCurtain,
} from "taro-ui";
import "./index.scss";

export default function Login(): ReturnType<Taro.FC> {
  const router = useRouter();

  const dispatch = useDispatch();
  const order: OrderStatus = useSelector((state: StoreStatus) => state.order);

  const [list, setList] = useState<any>([
    {
      title: "2020数学语文英语分析",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F7.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "2021数学语文英语分析",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "2022数学语文英语分析",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "2023数学语文英语分析",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F7.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "2024数学语文英语分析",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "2020数学语文英语分析",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
  ]);

  const handleClick = () => {
    console.log(123);
  };

  const handleDetail = () => {
    Taro.redirectTo({
      url: "/pages/course/detail",
    });
  };

  // TODO  {order.counter.num} 具体到某一个值
  console.log("router", router, order);
  return (
    <View className="index">
      <AtNavBar
        // customStyle={{ marginTop: "50rpx" }}
        onClickRgIconSt={handleClick}
        onClickRgIconNd={handleClick}
        onClickLeftIcon={handleClick}
        title="拼团课程"
        color="#000"
        leftText="返回"
        leftIconType="chevron-left"
        rightFirstIconType="search"
        // rightSecondIconType="user"
      ></AtNavBar>
      <View
        style={{
          backgroundColor: "#e9e9e9",
          padding: "20px",
          minHeight: "100vh",
        }}
      >
        {list.map((item, index) => {
          return (
            <View
              style={{
                display: "flex",
                backgroundColor: "white",
                padding: "10px",
                marginBottom: "20px",
                borderRadius: "5px",
                position: "relative",
              }}
              onClick={handleDetail}
            >
              <Image
                style={{ height: "100px", width: "100px" }}
                src={item.img}
              ></Image>

              <View>
                <View className="course-title">{item.title}</View>
                <Image
                  style={{ height: "25px", width: "150px" }}
                  src={item.imgs}
                ></Image>
                <View className="course-price">￥49.00</View>
              </View>
              <View className="course-btn">拼团</View>
            </View>
          );
        })}
      </View>
    </View>
  );
}

// Login.config = {
//   navigationBarTitleText: "拼团课程",
// //   navigationStyle: "custom",
//   enablePullDownRefresh: true,
//   backgroundTextStyle: "dark",
// } as Taro.PageConfig;
