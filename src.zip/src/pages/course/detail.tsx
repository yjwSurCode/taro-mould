/* eslint-disable jsx-quotes */
import { Component, useRef, useState } from "react";
import Taro, { useRouter } from "@tarojs/taro";
import { useDispatch, useSelector } from "react-redux";
import {
  View,
  Button,
  Image,
  Text,
  Picker,
  Swiper,
  SwiperItem,
} from "@tarojs/components";
import { add, asyncAdd } from "../../store/actions";
import { StoreStatus, OrderStatus } from "../../store/types/index";
import {
  AtTabs,
  AtTabsPane,
  AtNavBar,
  AtModal,
  AtModalAction,
  AtModalContent,
  AtModalHeader,
  AtCurtain,
  AtList,
  AtTabBar,
  AtListItem,
} from "taro-ui";
import "./index.scss";

export default function Login(): ReturnType<Taro.FC> {
  const router = useRouter();

  const dispatch = useDispatch();
  const order: OrderStatus = useSelector((state: StoreStatus) => state.order);

  const [list, setList] = useState<any>([
    {
      title: "坐看云起1",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F7.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "坐看云起2",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
    {
      title: "坐看云起3",
      img: "http://rbleiojei.hn-bkt.clouddn.com/design%2F6.png",
      imgs: "http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png",
    },
  ]);

  const handleClick = () => {
    console.log(123);
    Taro.switchTab({
      url: "/pages/course/index",
    });
  };

  // TODO  {order.counter.num} 具体到某一个值
  console.log("router", router, order);
  return (
    <View className="index">
      <AtNavBar
        // customStyle={{ marginTop: "50rpx" }}
        onClickRgIconSt={handleClick}
        onClickRgIconNd={handleClick}
        onClickLeftIcon={handleClick}
        // title="拼团课程"
        color="#000"
        leftText="返回"
        leftIconType="chevron-left"
        // rightFirstIconType="search"
        rightFirstIconType="bullet-list"
        // rightSecondIconType="user"
      ></AtNavBar>
      <Swiper
        className="test-h"
        indicatorColor="#999"
        indicatorActiveColor="#333"
        vertical
        circular
        indicatorDots
        autoplay
        duration={100}
      >
        <SwiperItem>
          <Image
            style={{ height: "100%", width: "100%" }}
            src="http://rbleiojei.hn-bkt.clouddn.com/design%2F1.png"
          ></Image>
        </SwiperItem>
        <SwiperItem>
          <Image
            style={{ height: "100%", width: "100%" }}
            src="http://rbleiojei.hn-bkt.clouddn.com/design%2F1.png"
          ></Image>
        </SwiperItem>
      </Swiper>
      <View className="detail-title">
        2020数学语文英语分析2020数学语文英语分析2020数学语文英语分析
      </View>
      <Image
        style={{ height: "200px", width: "100%" }}
        src="http://rbleiojei.hn-bkt.clouddn.com/design%2F9.png"
      ></Image>
      {list.map((item, index) => {
        return (
          <View
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "10px",
            }}
          >
            <Image
              style={{ height: "50px", width: "50px", marginRight: "10px" }}
              src="http://rbleiojei.hn-bkt.clouddn.com/design%2F4.png"
            ></Image>
            <View style={{ fontSize: "17px" }}>{item.title}</View>
            <Image
              style={{ height: "40px", width: "200px" }}
              src="http://rbleiojei.hn-bkt.clouddn.com/design%2F3.png"
            ></Image>
          </View>
        );
      })}
      <AtList>
        <AtListItem
          title="曹学坤"
          note="数学名师"
          extraText=""
          arrow="right"
          thumb="http://img12.360buyimg.com/jdphoto/s72x72_jfs/t10660/330/203667368/1672/801735d7/59c85643N31e68303.png"
        />
      </AtList>

      <Image
        style={{ height: "300px", width: "100%", position: "absolute" }}
        src="http://rbleiojei.hn-bkt.clouddn.com/design%2F10.png"
      ></Image>

      <Image
        style={{
          height: "60px",
          width: "100%",
          position: "fixed",
          bottom: "0px",
        }}
        src="http://rbleiojei.hn-bkt.clouddn.com/design%2F11.png"
      ></Image>
    </View>
  );
}
