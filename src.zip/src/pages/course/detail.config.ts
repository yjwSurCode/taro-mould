export default {
  navigationBarTitleText: "",
  //   navigationStyle: "custom",
  enablePullDownRefresh: true,
  backgroundTextStyle: "dark",
};
