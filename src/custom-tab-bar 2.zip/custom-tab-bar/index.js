Component({
  data: {
    selected: 0,
    color: "#7A7E83",
    selectedColor: "#3cc51f",
    list: [{
      text: "首页",
      pagePath: "pages/home/index",
      iconPath: "./assets/Slice 16@3x.png",
      selectedIconPath: "./assets/select-home.png",
    },
    {
      text: "展示",
      pagePath: "pages/exhibition-list/index",
      iconPath: "./assets/Slice 17@3x.png",
      selectedIconPath: "./assets/select-exhibition.png",
    },
    {
      text: "我的",
      pagePath: "pages/my/index",
      iconPath: "./assets/Slice 18@3x.png",
      selectedIconPath: "./assets/select-my.png",
    },]
  },
  attached() {
  },
  methods: {
    switchTab(e) {

      const data = e.currentTarget.dataset
      const url = data.path
      console.log('e', e, url)
      wx.switchTab({ url })
      this.setData({
        selected: data.index
      })
    }
  }
})