export default {
  "component": true
}